﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    class operacoines
    {public double suma(double x, double y)
        {
            return x + y;
        }
        public double resta(double x, double y)
        {
            return x - y;
        }
        public double multiplicacion(double x, double y)
        {
            return x * y;
        }
        public double division(double x, double y)
        {
            return x / y;
            
        }
    }
}
